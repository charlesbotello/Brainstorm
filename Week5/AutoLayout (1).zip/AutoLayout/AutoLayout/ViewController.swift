//
//  ViewController.swift
//  AutoLayout
//
//  Created by Afshan Irfan on 2021-04-23.
//  Copyright © 2021 Fahad Idrees. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

